<?php
// Site configuration.

// Server information.
$Proto = "http://";
$Host = $_SERVER['SERVER_NAME'];
$Base = "/~nserickson/dbtest/";

// Title to use in browser title bar.
$Title = "Cars Database";
$Name = "N Erickson";
$Email = "nserickson@uiowa.edu";
//$Logo = "dial.png";

// DB connection (from  mysql_db_info file).
$DBUser = "nserickson";
$DBName = "db_nserickson";
$DBHost = "dbdev.cs.uiowa.edu";
$DBPasswd = "iE+w8KqxPYUq";
?>

#!/bion/sh

# Change DBPASSWORD, DBUSER, DBHOST, to match values
#your mysql_db_info filr on the webdev server
mysql --password="iE+w8KqxPYUq" --user="nserickson" --host="dbdev.cs.uiowa.edu" "db_nserickson"
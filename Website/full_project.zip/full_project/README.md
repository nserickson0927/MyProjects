# Informatics-Project

clone a repository to any directory
1. make a new directory(folder) or empty an existing directory
2. go to github and find the repository you want to clone
3. click on clone and copy the web address displayed
4. go to terminal and navigate until you are in the directory you want to clone to
5. type 'git clone' and paste the web address and press enter
6. you may have to type your password and username.

after cloning just use 'git pull' to update the contents of the directory

to upload to the repository(assuming you are a contributor)
1. go to directory that holds the repository where the files are that you want to upload
2. type 'git status', this will tell you if there are files that have been modified are added
3. type 'git add (. or filename(s)), the period will upload everything, specify files if there are some that you don't want to upload (i.e. config.php/db.sh)
4. type 'git commit -m '(message)'', for the message i reccomend either the date or the name of the bug fix.
5. type 'git push', this will update the files on the repository
6. type 'git status' this should show that everything is up to date, unless you have files that you didn't update like config.php or db.sh.

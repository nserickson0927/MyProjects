<html lang="en">
<body>
    <p>
        Thank you for submitting you Zoo Application Form.<br>
        We have filed the following information for you.<br>
        Name: <?php echo $_POST["name"]; ?><br>
        Telephone: <?php echo $_POST['telephone']; ?><br>
        E-mail: <?php echo $_POST['email']; ?><br>
        Birthday: <?php echo $_POST['birthDate']; ?><br>
        Gender: <?php echo $_POST['gender']; ?><br>
        Comments: <?php echo $_POST['comments']; ?><br>
    </p>
</body>
</html>